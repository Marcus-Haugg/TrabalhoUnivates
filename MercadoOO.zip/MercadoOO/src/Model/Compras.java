/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author marcu
 */
public class Compras {
    
    private int id;
    private String formaPagamento;
    private double valorTotal;
    private String dataCompra;
    private String descricaoCompra;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public String getDataCompra() {
        return dataCompra;
    }

    public void setDataCompra(String dataCompra) {
        this.dataCompra = dataCompra;
    }

    public String getDescricaoCompra() {
        return descricaoCompra;
    }

    public void setDescricaoCompra(String descricaoCompra) {
        this.descricaoCompra = descricaoCompra;
    }
    
    public void imprimiAtributos(){
        System.out.println("ID:" + id);
        System.out.println("Froma de Pagamento:" + formaPagamento);
        System.out.println("Valor total da compra:" + valorTotal);
        System.out.println("Data da compra:" + dataCompra);
        System.out.println("Descrição da compra:" + descricaoCompra);
    }
    
}
